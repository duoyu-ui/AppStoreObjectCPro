
#import "AppDelegate.h"
#import "AppViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self setWindow:[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]]];
    [self.window setBackgroundColor:[UIColor whiteColor]];
    [self.window makeKeyAndVisible];
    [self setRootViewController];
    return YES;
}

- (void)setRootViewController
{
  AppViewController *rootViewController = [[AppViewController alloc] init];
  [self.window setRootViewController:rootViewController];
}

@end
