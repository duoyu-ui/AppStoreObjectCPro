
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

#define URL_LOCAL_INDEX                   @"Web/index.html"
#define URL_NETWORK_INDEX                 @"https://binaryify.github.io/vue-tetris/?lan=zh"

@interface AppViewController : UIViewController

#pragma mark 初始化 - 网络
- (instancetype)initWithHTMLUrlString:(NSString *)htmlUrlString;

#pragma mark 初始化 - 本地
- (instancetype)initWithLocalHTMLString:(NSString *)htmlUrlString;

@end

