
#import "AppViewController.h"

@interface AppViewController () <WKUIDelegate, WKNavigationDelegate>
@property (nonatomic, copy) NSString *htmlUrlString;
@property (nonatomic, assign) BOOL isLocalHTMLString;
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) WKWebViewConfiguration *config;
@end

@implementation AppViewController

- (instancetype)initWithHTMLUrlString:(NSString *)htmlUrlString
{
    self = [super init];
    if (self) {
        _isLocalHTMLString = NO;
        _htmlUrlString = htmlUrlString;
    }
    return self;
}

- (instancetype)initWithLocalHTMLString:(NSString *)htmlUrlString
{
    self = [self initWithHTMLUrlString:htmlUrlString];
    if (self) {
        _isLocalHTMLString = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[self colorWithHexString:(@"#159588")]];
    
    [self startLoadRequestWebHtml];
}

- (void)startLoadRequestWebHtml
{
    if (_isLocalHTMLString) {
        NSString *urlString = [NSString stringWithFormat:@"%@", self.htmlUrlString];
        NSURL *baseURL = [NSURL URLWithString:urlString relativeToURL:[[NSBundle mainBundle] bundleURL]];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:baseURL];
        [request setTimeoutInterval:30.0f];
        [self.webView loadRequest:request];
    } else {
        NSString *urlString = self.htmlUrlString;
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
        [request setTimeoutInterval:30.0f];
        [self.webView loadRequest:request];
    }
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    self.webView.hidden = YES;
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [self performSelector:@selector(showWebView) withObject:self afterDelay:0.0f];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    [self performSelector:@selector(showWebView) withObject:self afterDelay:0.0f];
}

- (void)showWebView
{
    self.webView.hidden = NO;
}


#pragma mark - WKUIDelegate

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:nil message:message ? : @"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * action = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }];
    [alertController addAction:action];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:message ? : @"" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }];
    
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:confirmAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler {
    
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:prompt message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.text = defaultText;
    }];
    UIAlertAction * action = [UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(alertController.textFields[0].text ? : @"");
    }];
    [alertController addAction:action];
    
    [self presentViewController:alertController animated:YES completion:nil];
}


#pragma mark - Getter/Setter

- (WKWebView *)webView
{
    if (!_webView) {
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:self.config];
        _webView.navigationDelegate = self;
        _webView.UIDelegate = self;
        _webView.allowsBackForwardNavigationGestures = NO; // 是否允许手势，后退前进等操作
        _webView.scrollView.bounces = YES; // 是否允许拖动效果
        _webView.hidden = YES;
        [self.view addSubview:_webView];
    }
    return _webView;
}

- (WKWebViewConfiguration *)config
{
    if (!_config) {
        _config = [[WKWebViewConfiguration alloc] init];
        _config.allowsInlineMediaPlayback = YES;
        // iOS系统版本 >= 9.0
        if (@available(iOS 9.0, *)) {
            _config.allowsPictureInPictureMediaPlayback = YES;
        }
    }
    return _config;
}


#pragma mark - Private

- (UIColor*)colorWithHexString:(NSString*)stringToConvert
{
    NSString*cString=[[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    if([cString length]< 6)
        return [UIColor whiteColor];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor whiteColor];
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

@end

