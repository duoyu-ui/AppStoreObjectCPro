
#import "AppDelegate.h"
#import "AppViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self setWindow:[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]]];
    [self.window setBackgroundColor:[UIColor whiteColor]];
    [self.window makeKeyAndVisible];
    [self setRootViewController];
    return YES;
}

- (void)setRootViewController
{
    AppViewController *rootViewController = [[AppViewController alloc] initWithLocalHTMLString:URL_LOCAL_INDEX];
    rootViewController = [[AppViewController alloc] initWithHTMLUrlString:URL_NETWORK_INDEX];
    [self.window setRootViewController:rootViewController];
}

@end

